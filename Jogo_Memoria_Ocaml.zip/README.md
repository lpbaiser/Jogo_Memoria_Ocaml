## Jogo da Memória em Linguagem Funcional - Ocaml

**Para executar o jogo**
 1. Navegar pelo terminal até a pasta do jogo cd /..
 2.  $ ocamc jogo.ml -o jogo
 3.  $ ./jogo
